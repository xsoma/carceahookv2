#pragma once
const char* LegitAimbotType[] =
{
	"Normal",
	"Smoothed",
	"Silent"
};
const char* LegitAimbotHitbox[] =
{
	"Head",
	"Neck",
	"Chest"
};
const char* ClantagList[] =
{
	"Off",
	"Xanity.cc",
	"CarceaHOOK"
};
const char* ConfigFiles[] =
{
	"CarceaHOOKConfig1.ini",
	"CarceaHOOKConfig2.ini",
	"CarceaHOOKConfig3.ini",
	"CarceaHOOKConfig4.ini",
	"CarceaHOOKConfig5.ini"
};
const char* MenuTabs[]
{
	"Rage",
	"Legit",
	"Visuals",
	"Misc",
	"Skins"
};
const char* RagebotTabs[]
{
	"Aimbot",
	"Antiaim"
};
const char* LegitbotTabs[]
{
	"Rifles",
	"Pistols",
	"Snipers"
};
const char* VisualsTabs[]
{
	"Players",
	"Others",
	"World"
};
const char* VisualsTabs2[]
{
	"All Players",
	"LocalPlayer"
};

const char* SkinsTabs[]
{
	"Pistols",
	"Rifles",
	"Snipers",
	"SMGs",
	"Heavy",
	"Knives/Gloves"
};
const char* ChamsMaterials[]
{
	"None",
	"Textured",
	"Flat",
	"Metallic",
	"Pulsing"
};
const char* ChamsBacktrack[]
{
	"Off",
	"All Ticks",
	"Last Tick"
};
const char* GlowStyles[]
{
	"Normal",
	"Pulsing",
	"Outline",
	"Pulsing Outline"
};
const char* AntiaimPitch[]
{
	"Off",
	"Down",
	"Up",
	"Custom"
};
const char* AntiaimYaw[]
{
	"Off",
	"Backwards",
	"Manual",
	"Custom"
};
const char* AntiaimYawBase[]
{
	"Local View",
	"At Target"
};
const char* AntiaimYawDesync[]
{
	"Off",
	"Positive",
	"Negative",
	"Invert"
};
const char* AntiaimYawDesyncAssistance[]
{
	"Off",
	"Break LBY",
	"Small Static Movements"
};
